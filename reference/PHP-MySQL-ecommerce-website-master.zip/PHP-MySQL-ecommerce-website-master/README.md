# A Complete PHP/MySQL based web application:


**Check Database Settings file for Username / password -- Admin User: admin / Password: 1234**


The complete ecommerce script with Paypal integration. Some of the features are as follow:

**Admin/Dashboard Area**

**Multi-level Category Management:**

-- Add Category 
-- Edit Category 
-- Delete Category 
-- Manage Category Logo
-- Manage Category Slider
-- Add Sub-Category 
-- Edit Sub-Category 
-- Delete Sub-Category 
-- Manage Sub-Category Slider

**Product Management:**

-- Multiple Product Image
-- Set Feature's Product
-- Product Description
-- Manage Product Reviews & Ratings
-- Product Stock Management
-- Offer / Discount Set
-- Unlimited Product Photo's
-- Related Product Selection
-- Add Product
-- Edit Product
-- Delete Product
-- Manage Product Category 

**Oders Management:**

 -- View All Order
 -- Awaiting Payment
 -- Awaiting Delivery
 
 **Payment Setting:**

 -- Unlimited Payment Method Creation.
 -- Add / Edit / Delete Payment Method
 -- Payment Method Icon Manage

**Frontend**

 -- Fully Responsive Design.
 -- Easy to Use Menu.
 -- Delighted Product View Section.
 -- Easy to product compare.
 -- Online Order & payment System.
 -- Product Rating system.
 -- Product Review System.
 -- SEO Friendly URL.
 -- Easy to Social Share System.
 -- User Registration & Login System.
 -- User Database.
 -- Easy to order system.
 -- Social Links.

**Menu Setting**

 -- Add / Edit / Delete Unlimited Menu.
 -- Add / Edit / Delete Menu Content.
 -- Set Menu Position

**CMS / Website Setting**

 -- General Setting
 -- Logo Setting
 -- Footer Logo Setting
 -- 4 Feature Setting
 -- Home Slider Setting
 -- 3 Top Images
 -- Home Text Slider
 -- Brand Logo Setting
 -- Cat Slider Setting
 -- Social Links
 -- Payment Icon
 -- Footer Menu

**User Panel**

 -- Fully Responsive Design.
 -- Easy to Registration.
 -- Trace Product Delivery.
 -- Online Order Management.
 -- Portfolio Management.
 -- Review Modify Facility.
 -- Product Comment's Panel.
 -- Report / Activity Section.
 -- SEO Friendly URL.
 -- Product Database.
 -- Easy to order system.

 
